﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MandiriTest.Models
{
    public class SkillLevel
    {
        [Key]
        public int skillLevelID { get; set; }
        [Column(TypeName = "varchar(500)")]
        public string skillLevelName { get; set; }
    }
}
