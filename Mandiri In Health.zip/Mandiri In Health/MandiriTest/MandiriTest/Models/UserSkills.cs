﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MandiriTest.Models
{
    public class UserSkills
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string userSkillID { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string username { get; set; }
        public int skillID { get; set; }
        public int skillLevelID { get; set; }

    }
}
