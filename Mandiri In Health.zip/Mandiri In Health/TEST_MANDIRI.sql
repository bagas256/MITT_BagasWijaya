/*
 Navicat Premium Data Transfer

 Source Server         : Latihan
 Source Server Type    : SQL Server
 Source Server Version : 15002080
 Source Host           : BAGAS-PC:1433
 Source Catalog        : TEST_MANDIRI
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 15002080
 File Encoding         : 65001

 Date: 26/08/2021 17:37:33
*/


-- ----------------------------
-- Table structure for __EFMigrationsHistory
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[__EFMigrationsHistory]') AND type IN ('U'))
	DROP TABLE [dbo].[__EFMigrationsHistory]
GO

CREATE TABLE [dbo].[__EFMigrationsHistory] (
  [MigrationId] nvarchar(150) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ProductVersion] nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
GO

ALTER TABLE [dbo].[__EFMigrationsHistory] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of __EFMigrationsHistory
-- ----------------------------
INSERT INTO [dbo].[__EFMigrationsHistory] ([MigrationId], [ProductVersion]) VALUES (N'20210826083945_Initial Create', N'5.0.9')
GO


-- ----------------------------
-- Table structure for SkillLevels
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[SkillLevels]') AND type IN ('U'))
	DROP TABLE [dbo].[SkillLevels]
GO

CREATE TABLE [dbo].[SkillLevels] (
  [skillLevelID] int  IDENTITY(1,1) NOT NULL,
  [skillLevelName] varchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[SkillLevels] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of SkillLevels
-- ----------------------------
SET IDENTITY_INSERT [dbo].[SkillLevels] ON
GO

INSERT INTO [dbo].[SkillLevels] ([skillLevelID], [skillLevelName]) VALUES (N'1', N'Junior')
GO

SET IDENTITY_INSERT [dbo].[SkillLevels] OFF
GO


-- ----------------------------
-- Table structure for Skills
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[Skills]') AND type IN ('U'))
	DROP TABLE [dbo].[Skills]
GO

CREATE TABLE [dbo].[Skills] (
  [skillID] int  IDENTITY(1,1) NOT NULL,
  [skillName] varchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[Skills] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Skills
-- ----------------------------
SET IDENTITY_INSERT [dbo].[Skills] ON
GO

INSERT INTO [dbo].[Skills] ([skillID], [skillName]) VALUES (N'1', N'.Net Core MVC')
GO

INSERT INTO [dbo].[Skills] ([skillID], [skillName]) VALUES (N'2', N'Rest API')
GO

INSERT INTO [dbo].[Skills] ([skillID], [skillName]) VALUES (N'3', N'Front End')
GO

SET IDENTITY_INSERT [dbo].[Skills] OFF
GO


-- ----------------------------
-- Table structure for UserProfiles
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[UserProfiles]') AND type IN ('U'))
	DROP TABLE [dbo].[UserProfiles]
GO

CREATE TABLE [dbo].[UserProfiles] (
  [username] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [name] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [address] varchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [date] datetime2(7)  NOT NULL,
  [email] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[UserProfiles] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of UserProfiles
-- ----------------------------
INSERT INTO [dbo].[UserProfiles] ([username], [name], [address], [date], [email]) VALUES (N'bagaswijaya', N'Bagas Wijaya', N'Jakarta Timur', N'2021-08-26 09:12:16.4630000', N'bagaswijaya256@gmail.com')
GO


-- ----------------------------
-- Table structure for Users
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[Users]') AND type IN ('U'))
	DROP TABLE [dbo].[Users]
GO

CREATE TABLE [dbo].[Users] (
  [username] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [password] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
GO

ALTER TABLE [dbo].[Users] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of Users
-- ----------------------------
INSERT INTO [dbo].[Users] ([username], [password]) VALUES (N'bagaswijaya', N'000')
GO


-- ----------------------------
-- Table structure for UserSkills
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[UserSkills]') AND type IN ('U'))
	DROP TABLE [dbo].[UserSkills]
GO

CREATE TABLE [dbo].[UserSkills] (
  [userSkillID] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [username] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [skillID] int  NOT NULL,
  [skillLevelID] int  NOT NULL
)
GO

ALTER TABLE [dbo].[UserSkills] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of UserSkills
-- ----------------------------
INSERT INTO [dbo].[UserSkills] ([userSkillID], [username], [skillID], [skillLevelID]) VALUES (N'1', N'bagaswijaya', N'0', N'0')
GO


-- ----------------------------
-- Primary Key structure for table __EFMigrationsHistory
-- ----------------------------
ALTER TABLE [dbo].[__EFMigrationsHistory] ADD CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED ([MigrationId])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Auto increment value for SkillLevels
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[SkillLevels]', RESEED, 2)
GO


-- ----------------------------
-- Primary Key structure for table SkillLevels
-- ----------------------------
ALTER TABLE [dbo].[SkillLevels] ADD CONSTRAINT [PK_SkillLevels] PRIMARY KEY CLUSTERED ([skillLevelID])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Auto increment value for Skills
-- ----------------------------
DBCC CHECKIDENT ('[dbo].[Skills]', RESEED, 3)
GO


-- ----------------------------
-- Primary Key structure for table Skills
-- ----------------------------
ALTER TABLE [dbo].[Skills] ADD CONSTRAINT [PK_Skills] PRIMARY KEY CLUSTERED ([skillID])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table UserProfiles
-- ----------------------------
ALTER TABLE [dbo].[UserProfiles] ADD CONSTRAINT [PK_UserProfiles] PRIMARY KEY CLUSTERED ([username])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table Users
-- ----------------------------
ALTER TABLE [dbo].[Users] ADD CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([username])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table UserSkills
-- ----------------------------
ALTER TABLE [dbo].[UserSkills] ADD CONSTRAINT [PK_UserSkills] PRIMARY KEY CLUSTERED ([userSkillID])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

